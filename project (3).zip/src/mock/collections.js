export const collections = [
  {
    id: 1,
    name: "Esenciales",
    description: "Piezas fundamentales para cada ocasión",
    coverImage: "essentials-collection.jpg"
  },
  {
    id: 2,
    name: "Edición Limitada",
    description: "Creaciones exclusivas para mentes audaces",
    coverImage: "limited-edition.jpg"
  }
];