export const testimonials = [
  {
    id: 1,
    name: "Ana Martínez",
    text: "Mi bolso Fashyel recibe más cumplidos que yo. ¡Me encanta!",
    product: "Bolso Editorial"
  },
  {
    id: 2,
    name: "Carlota Gómez",
    text: "La calidad supera con creces el precio. Una inversión que vale cada centavo.",
    product: "Clutch Nocturno"
  }
];