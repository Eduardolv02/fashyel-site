module.exports = {
  theme: {
    extend: {
      colors: {
        primary: '#1E1E1E',
        secondary: '#F3D3D3',
        accent: '#D4AF37',
        background: '#FFFFFF',
      },
    },
  },
};